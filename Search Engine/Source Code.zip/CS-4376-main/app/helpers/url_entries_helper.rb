module UrlEntriesHelper
end
